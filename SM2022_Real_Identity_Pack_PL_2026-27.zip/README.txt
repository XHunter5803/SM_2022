SM2022 REAL IDENTITY DATA PACK — PREMIER LEAGUE 2026/27
================================================================

MAIN FILE
---------
SM2022_Real_Identity_Pack_PL_2026-27.json

CONTENTS
--------
- 31 verified real-player identity/photo overrides
- 20 Premier League 2026/27 club identity overrides
- 20 real stadium-name overrides
- Premier League (LeagueData ID 28)
- FA Cup (CupData ID 2)
- Direct SoccerWiki CDN image URLs for player photos, club crests, league logo and cup logo

HOW TO USE
----------
1. Upload the JSON file to a public web host.
2. The URL must be a DIRECT, public URL that opens the JSON itself without a login/password.
3. In SM2022, open Custom Data Pack and paste that direct URL.
4. Start a NEW career/save after selecting the data pack if the game requires it.

IMPORTANT TECHNICAL LIMIT
-------------------------
The custom Data Pack format exposed by SM2022 only provides these override fields:
PlayerData: ID, Forename, Surname, ImageURL
ClubData: ID, Name, ShortName, ImageURL
LeagueData: ID, Name, ImageURL
CupData: ID, Name, ImageURL
StadiumData: ID, Name

That means this file can change real names/images/crests and stadium/competition labels,
but this JSON format does NOT provide fields for:
- moving a player to a different club
- adding/removing league members
- current 2026/27 transfer squads
- ratings/potential
- age/date of birth
- wages/contracts
- tactics/finances

Entries with IDs that do not exist in the SM2022 database may be ignored by the game.

IMAGE HOSTING
-------------
The image URLs in this pack use SoccerWiki's public CDN pattern:
Player: https://cdn.soccerwiki.org/images/player/<ID>.png
Club:  https://cdn.soccerwiki.org/images/logos/clubs/<ID>.png
League: https://cdn.soccerwiki.org/images/logos/leagues/<ID>.png
Cup:    https://cdn.soccerwiki.org/images/logos/cups/<ID>.png

PUBLIC URL
----------
A ChatGPT sandbox link is only a download link; SM2022 cannot import it directly.
For a permanent game-import URL, upload the JSON to a PUBLIC GitHub repository and use:
https://raw.githubusercontent.com/<USERNAME>/<REPOSITORY>/<BRANCH>/SM2022_Real_Identity_Pack_PL_2026-27.json

This pack intentionally keeps the JSON structure exactly to the SM2022 format shown in-game.
